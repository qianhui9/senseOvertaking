import math
import torch
import argparse
import numpy as np
import torch.optim as optim
from model import Actor, Critic
from utils import get_action
from collections import deque
from hparams import HyperParams as hp
import matplotlib.pyplot as plt
import time
import os
import pickle
import seaborn as sns
from matplotlib.ticker import FuncFormatter

def smooth(arr):
    smoothing_rate = 0.5
    temp_arr = np.zeros(len(arr))
    temp_arr[0] = arr[0]
    for i in range(1, len(arr)):
        temp_arr[i] = smoothing_rate * temp_arr[i-1] + (1-smoothing_rate) * arr[i]
    return temp_arr

if __name__=="__main__":
    x1 = np.loadtxt("score_avg_UAV_PG.txt")
    x2 = np.loadtxt("score_avg_UAV_PPO.txt")
    x3 = np.loadtxt("score_avg_UAV_TRPO.txt")
    x1 = smooth(x1)
    x2 = smooth(x2)
    x3 = smooth(x3)
    iter = range(10000)
    sns.set(style="whitegrid", font_scale=1.1)
    sns.tsplot(time=iter, data=x1, color="r",linestyle='-',  condition="Vanilla_PG")
    sns.tsplot(time=iter, data=x2, color="b", linestyle='--',condition="PPO")
    sns.tsplot(time=iter, data=x3, color="g",linestyle='-.', condition="TPRO")

    plt.ticklabel_format(axis='y', style='sci', scilimits=(0, 4))
    plt.ylabel("Reward", fontsize=15)
    plt.xlabel("Iteration Number", fontsize=15)
    plt.savefig("different_algorithms.pdf",format='pdf')
    plt.show()





