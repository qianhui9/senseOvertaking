import math
import torch
import argparse
import numpy as np
import torch.optim as optim
from model import Actor, Critic
from utils import get_action
from collections import deque
from hparams import HyperParams as hp
import matplotlib.pyplot as plt
import time
import os
import pickle
import seaborn as sns
from matplotlib.ticker import FuncFormatter

def smooth(arr):
    smoothing_rate = 0.5
    temp_arr = np.zeros(len(arr))
    temp_arr[0] = arr[0]
    for i in range(1, len(arr)):
        temp_arr[i] = smoothing_rate * temp_arr[i-1] + (1-smoothing_rate) * arr[i]
    return temp_arr

if __name__=="__main__":
    x1 = np.loadtxt("agent_UAV_cfd.txt")
    x2 = np.loadtxt("agent_UAV_chd.txt")
    x3 = np.loadtxt("agent_UAV_dcfd.txt")
    x4 = np.loadtxt("agent_UAV_dchd.txt")
    x1 = smooth(x1)
    x2 = smooth(x2)
    x3 = smooth(x3)
    x4 = smooth(x4)

    iter = range(10000)
    sns.set(style="whitegrid", font_scale=1.1)

    sns.tsplot(time=iter, data=x1, color="r",linestyle='-',  condition="coupled full-duplex")
    sns.tsplot(time=iter, data=x2, color="g", linestyle='--',condition="coupled half-duplex")
    sns.tsplot(time=iter, data=x3, color="b",linestyle='-.', condition="decoupled full-duplex")
    sns.tsplot(time=iter, data=x4, color="gray", linestyle=':', condition="decoupled half-duplex")

    plt.ticklabel_format(axis='y', style='sci', scilimits=(0, 4))
    plt.ylabel("Reward", fontsize=15)
    plt.xlabel("Iteration Number", fontsize=15)
    plt.savefig("different_mode.pdf",format='pdf')
    plt.show()





